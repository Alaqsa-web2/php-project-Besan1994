<!DOCTYPE html>
<html>

	<head>
		<title>Welcome  To SocialMedia - Sin up, Log in, Chat </title>
		<link rel="stylesheet" type="text/css" href="css/index.css">
	</head>

<body>

	<div id="header">
		<div class="head-view">
			<ul>
				<li><b>SocialMedia</b></li>
				<li></li>
				<li></li>
				<li></li>
				<li><a href="signin.php" title="Sign in"><button class="btn-sign-in" value="Sign in">Sign in</button></a></li>
				<li><a href="signup.php" title="Sign up"><button class="btn-sign-up" value="Sign up">Sign up</button></a></li>
			</ul>
		</div>
	</div>

	<div id="container">
		<div class="image-display">
				<img src="image/pngegg.png" class="img-style" />
		</div>
	</div>

</body>

</html>